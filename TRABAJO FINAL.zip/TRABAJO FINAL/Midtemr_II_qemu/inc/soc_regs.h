#ifndef __SOC_REGS_H__
#define __SOC_REGS_H__
#include <stdint.h>

#define EMU_GPIO_BASE 0x80200000
#define UART_BASE 0x10000000



#endif